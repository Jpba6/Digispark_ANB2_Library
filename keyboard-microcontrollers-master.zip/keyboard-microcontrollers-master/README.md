# Teclado em PT-BR para microcontroladores
Este repositório é para códigos referente a teclados em português do Brasil

Os teclados adaptados por Samuel Pereira de Godoy são dos microcontroladores Attiny85 (Digispark) e Atmega32u4
as bibliotecas estão totalmente em português do brasil com cedilha (ç) e interrogação (?).

As bibliotecas que foram adaptadas foram escritas em c e podem ser gravadas com a IDE do Arduino


Donate 
XMR (Monero) : 43Uz1ZSHBGdifDYefK49HvVWnpRvtwQocVFavujUcfXfWiMVbs3CeApLN2XGzw3VJFKc6NKNEEazfQX7KpdZ55DNJURf4DF
